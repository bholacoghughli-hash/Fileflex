package com.example.ui.screens.editor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.graphics.Rect
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Crop
import androidx.compose.material.icons.filled.Draw
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PhotoSizeSelectLarge
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.ImageAdjustmentState
import com.example.engine.ImageDrawStroke
import com.example.engine.ImageEditEngine
import com.example.engine.ImageTextItem
import com.example.localization.AppLanguage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

enum class ImageEditorTab {
    ADJUST,
    TRANSFORM,
    DRAW,
    TEXT_WATERMARK,
    EXPORT
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ImageEditorView(
    initialUri: Uri?,
    initialFileName: String,
    language: AppLanguage,
    onSaveToWorkspace: (File, String) -> Unit,
    onOpenFile: (File) -> Unit,
    onShareFile: (File) -> Unit,
    onSaveToDownloads: ((File) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var originalBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var fileName by remember { mutableStateOf(initialFileName.ifBlank { "image.jpg" }) }
    var isLoading by remember { mutableStateOf(false) }
    var statusMessage by remember { mutableStateOf("") }

    var selectedTab by remember { mutableStateOf(ImageEditorTab.ADJUST) }

    // Adjustment state
    var brightness by remember { mutableFloatStateOf(0f) }
    var contrast by remember { mutableFloatStateOf(0f) }
    var saturation by remember { mutableFloatStateOf(0f) }
    var exposure by remember { mutableFloatStateOf(0f) }
    var blurRadius by remember { mutableIntStateOf(0) }
    var isGrayscale by remember { mutableStateOf(false) }
    var isSepia by remember { mutableStateOf(false) }
    var isInverted by remember { mutableStateOf(false) }

    // Transform state
    var rotationDegrees by remember { mutableFloatStateOf(0f) }
    var flipHorizontal by remember { mutableStateOf(false) }
    var flipVertical by remember { mutableStateOf(false) }
    var resizeScale by remember { mutableIntStateOf(100) } // 100%

    // Drawing state
    val strokes = remember { mutableStateListOf<ImageDrawStroke>() }
    var brushColor by remember { mutableStateOf(Color(0xFFEF4444)) }
    var brushSize by remember { mutableFloatStateOf(8f) }
    var isEraser by remember { mutableStateOf(false) }

    // Text & Watermark state
    val textItems = remember { mutableStateListOf<ImageTextItem>() }
    var watermarkText by remember { mutableStateOf("") }
    var watermarkOpacity by remember { mutableFloatStateOf(0.6f) }
    var showAddTextDialog by remember { mutableStateOf(false) }
    var textToAdd by remember { mutableStateOf("") }

    // Export options
    var exportFormat by remember { mutableStateOf("jpg") }
    var exportQuality by remember { mutableIntStateOf(90) }
    var exportedFile by remember { mutableStateOf<File?>(null) }

    // Image Picker
    val imagePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        uri?.let {
            scope.launch {
                isLoading = true
                statusMessage = "Decoding image..."
                try {
                    val bmp = withContext(Dispatchers.IO) {
                        ImageEditEngine.loadBitmapFromUri(context, it)
                    }
                    if (bmp != null) {
                        originalBitmap = bmp
                        fileName = "edited_${System.currentTimeMillis()}.$exportFormat"
                        // reset states
                        strokes.clear()
                        textItems.clear()
                        brightness = 0f
                        contrast = 0f
                        saturation = 0f
                        exposure = 0f
                        rotationDegrees = 0f
                        flipHorizontal = false
                        flipVertical = false
                        isGrayscale = false
                        isSepia = false
                        isInverted = false
                    }
                } catch (e: Exception) {
                    statusMessage = "Could not load image: ${e.message}"
                } finally {
                    isLoading = false
                }
            }
        }
    }

    // Load initial URI if provided
    LaunchedEffect(initialUri) {
        if (initialUri != null && originalBitmap == null) {
            isLoading = true
            statusMessage = "Loading image..."
            try {
                val bmp = withContext(Dispatchers.IO) {
                    ImageEditEngine.loadBitmapFromUri(context, initialUri)
                }
                originalBitmap = bmp
            } catch (_: Exception) {
                statusMessage = "Failed to load initial image"
            } finally {
                isLoading = false
            }
        }
    }

    // Export function
    fun exportImage() {
        val src = originalBitmap ?: return
        scope.launch {
            isLoading = true
            statusMessage = "Applying edits & encoding..."
            try {
                val targetW = if (resizeScale < 100) (src.width * (resizeScale / 100f)).toInt().coerceAtLeast(1) else null
                val targetH = if (resizeScale < 100) (src.height * (resizeScale / 100f)).toInt().coerceAtLeast(1) else null

                val state = ImageAdjustmentState(
                    brightness = brightness,
                    contrast = contrast,
                    saturation = saturation,
                    exposure = exposure,
                    isGrayscale = isGrayscale,
                    isSepia = isSepia,
                    isInverted = isInverted,
                    rotationDegrees = rotationDegrees,
                    flipHorizontal = flipHorizontal,
                    flipVertical = flipVertical,
                    blurRadius = blurRadius,
                    watermarkText = watermarkText,
                    watermarkOpacity = watermarkOpacity,
                    targetWidth = targetW,
                    targetHeight = targetH,
                    exportFormat = exportFormat,
                    exportQuality = exportQuality
                )

                val outFile = File(context.cacheDir, "edited_${System.currentTimeMillis()}.$exportFormat")
                val result = ImageEditEngine.applyEditsAndExport(
                    sourceBitmap = src,
                    adjustments = state,
                    strokes = strokes.toList(),
                    textItems = textItems.toList(),
                    cropRect = null,
                    outputFile = outFile
                )

                exportedFile = result
                onSaveToWorkspace(result, "IMAGE")
                statusMessage = "Image saved successfully!"
            } catch (e: Exception) {
                statusMessage = "Export failed: ${e.message}"
            } finally {
                isLoading = false
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // Top Toolbar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 2.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Image,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.secondary,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = fileName,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                            maxLines = 1
                        )
                        originalBitmap?.let {
                            Text(
                                text = "${it.width} × ${it.height} px • ${resizeScale}% scale",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = { imagePickerLauncher.launch("image/*") },
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Open Image", fontSize = 12.sp)
                    }
                    if (originalBitmap != null) {
                        Spacer(modifier = Modifier.width(6.dp))
                        OutlinedButton(
                            onClick = {
                                brightness = 0f
                                contrast = 1f
                                saturation = 1f
                                exposure = 0f
                                isGrayscale = false
                                isSepia = false
                                isInverted = false
                                rotationDegrees = 0f
                                flipHorizontal = false
                                flipVertical = false
                                blurRadius = 0
                                resizeScale = 100
                                watermarkText = ""
                                strokes.clear()
                                textItems.clear()
                                exportedFile = null
                            },
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text("Reset", fontSize = 12.sp)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Button(
                            onClick = { exportImage() },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Save, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Export", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        if (originalBitmap == null) {
            // Empty State
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                ElevatedCard(
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.secondaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Image,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.secondary,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(16.dp))
                        Text(
                            text = "Full-Featured Image Editor",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Crop, resize, rotate, flip, adjust brightness, contrast, saturation, apply filters, sketch, draw, add text, watermarks, and export to JPG, PNG, WEBP, or BMP.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = { imagePickerLauncher.launch("image/*") },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Select Image to Edit")
                        }
                    }
                }
            }
        } else {
            // Live Preview Canvas
            val bmp = originalBitmap!!
            val activeStroke = remember { mutableStateListOf<Pair<Float, Float>>() }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .background(Color(0xFF0F172A))
                    .padding(10.dp),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .pointerInput(selectedTab) {
                            if (selectedTab == ImageEditorTab.DRAW) {
                                detectDragGestures(
                                    onDragStart = { offset ->
                                        activeStroke.clear()
                                        activeStroke.add(Pair(offset.x, offset.y))
                                    },
                                    onDrag = { change, _ ->
                                        change.consume()
                                        activeStroke.add(Pair(change.position.x, change.position.y))
                                    },
                                    onDragEnd = {
                                        if (activeStroke.size > 1) {
                                            strokes.add(
                                                ImageDrawStroke(
                                                    points = activeStroke.toList(),
                                                    color = brushColor.toArgb(),
                                                    strokeWidth = brushSize,
                                                    isEraser = isEraser
                                                )
                                            )
                                        }
                                        activeStroke.clear()
                                    }
                                )
                            }
                        }
                ) {
                    Image(
                        bitmap = bmp.asImageBitmap(),
                        contentDescription = "Original image",
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )

                    // Draw Stroke Canvas Overlay
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        for (stroke in strokes) {
                            if (stroke.points.size > 1) {
                                val c = if (stroke.isEraser) Color.White else Color(stroke.color)
                                for (i in 0 until stroke.points.size - 1) {
                                    drawLine(
                                        color = c,
                                        start = Offset(stroke.points[i].first, stroke.points[i].second),
                                        end = Offset(stroke.points[i + 1].first, stroke.points[i + 1].second),
                                        strokeWidth = stroke.strokeWidth
                                    )
                                }
                            }
                        }

                        if (activeStroke.size > 1) {
                            val c = if (isEraser) Color.White else brushColor
                            for (i in 0 until activeStroke.size - 1) {
                                drawLine(
                                    color = c,
                                    start = Offset(activeStroke[i].first, activeStroke[i].second),
                                    end = Offset(activeStroke[i + 1].first, activeStroke[i + 1].second),
                                    strokeWidth = brushSize
                                )
                            }
                        }
                    }

                    // Render Custom Text Stamps
                    for (item in textItems) {
                        Box(
                            modifier = Modifier
                                .padding(start = item.x.dp, top = item.y.dp)
                                .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = item.text,
                                fontSize = (item.textSize / 2f).sp,
                                color = Color(item.color),
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Render Watermark preview
                    if (watermarkText.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.BottomEnd)
                                .padding(12.dp)
                        ) {
                            Text(
                                text = watermarkText,
                                color = Color.White.copy(alpha = watermarkOpacity),
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Bottom Editing Tools Tabs & Controls
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 3.dp
            ) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    // Tool category tabs
                    LazyRow(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        item {
                            FilterChip(
                                selected = selectedTab == ImageEditorTab.ADJUST,
                                onClick = { selectedTab = ImageEditorTab.ADJUST },
                                leadingIcon = { Icon(Icons.Default.Tune, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                label = { Text("Adjust") }
                            )
                        }
                        item {
                            FilterChip(
                                selected = selectedTab == ImageEditorTab.TRANSFORM,
                                onClick = { selectedTab = ImageEditorTab.TRANSFORM },
                                leadingIcon = { Icon(Icons.Default.RotateRight, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                label = { Text("Transform") }
                            )
                        }
                        item {
                            FilterChip(
                                selected = selectedTab == ImageEditorTab.DRAW,
                                onClick = { selectedTab = ImageEditorTab.DRAW },
                                leadingIcon = { Icon(Icons.Default.Draw, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                label = { Text("Draw") }
                            )
                        }
                        item {
                            FilterChip(
                                selected = selectedTab == ImageEditorTab.TEXT_WATERMARK,
                                onClick = { selectedTab = ImageEditorTab.TEXT_WATERMARK },
                                leadingIcon = { Icon(Icons.Default.TextFields, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                label = { Text("Text / Watermark") }
                            )
                        }
                        item {
                            FilterChip(
                                selected = selectedTab == ImageEditorTab.EXPORT,
                                onClick = { selectedTab = ImageEditorTab.EXPORT },
                                leadingIcon = { Icon(Icons.Default.PhotoSizeSelectLarge, contentDescription = null, modifier = Modifier.size(16.dp)) },
                                label = { Text("Format & Quality") }
                            )
                        }
                    }

                    // Panel for active tab
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(180.dp)
                            .padding(horizontal = 16.dp, vertical = 8.dp)
                            .verticalScroll(rememberScrollState())
                    ) {
                        when (selectedTab) {
                            ImageEditorTab.ADJUST -> {
                                Text("Brightness: ${brightness.toInt()}", style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = brightness,
                                    onValueChange = { brightness = it },
                                    valueRange = -100f..100f
                                )

                                Text("Contrast: ${contrast.toInt()}", style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = contrast,
                                    onValueChange = { contrast = it },
                                    valueRange = -100f..100f
                                )

                                Text("Saturation: ${saturation.toInt()}", style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = saturation,
                                    onValueChange = { saturation = it },
                                    valueRange = -100f..100f
                                )

                                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    FilterChip(
                                        selected = isGrayscale,
                                        onClick = {
                                            isGrayscale = !isGrayscale
                                            if (isGrayscale) isSepia = false
                                        },
                                        label = { Text("Grayscale") }
                                    )
                                    FilterChip(
                                        selected = isSepia,
                                        onClick = {
                                            isSepia = !isSepia
                                            if (isSepia) isGrayscale = false
                                        },
                                        label = { Text("Sepia") }
                                    )
                                    FilterChip(
                                        selected = isInverted,
                                        onClick = { isInverted = !isInverted },
                                        label = { Text("Invert") }
                                    )
                                }
                            }

                            ImageEditorTab.TRANSFORM -> {
                                Text("Rotate & Flip", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                                Spacer(modifier = Modifier.height(8.dp))
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    OutlinedButton(onClick = { rotationDegrees = (rotationDegrees + 90f) % 360f }) {
                                        Icon(Icons.Default.RotateRight, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("+90°")
                                    }
                                    OutlinedButton(onClick = { flipHorizontal = !flipHorizontal }) {
                                        Icon(Icons.Default.Flip, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(if (flipHorizontal) "Unflip H" else "Flip H")
                                    }
                                    OutlinedButton(onClick = { flipVertical = !flipVertical }) {
                                        Text(if (flipVertical) "Unflip V" else "Flip V")
                                    }
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                Text("Resize Scale: $resizeScale%", style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = resizeScale.toFloat(),
                                    onValueChange = { resizeScale = it.toInt() },
                                    valueRange = 25f..100f,
                                    steps = 3
                                )
                            }

                            ImageEditorTab.DRAW -> {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Freehand Brush", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                                    TextButton(onClick = { strokes.clear() }) {
                                        Text("Clear Strokes")
                                    }
                                }

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    listOf(
                                        Color(0xFFEF4444),
                                        Color(0xFF3B82F6),
                                        Color(0xFF10B981),
                                        Color(0xFFF59E0B),
                                        Color(0xFFFFFFFF),
                                        Color(0xFF000000)
                                    ).forEach { color ->
                                        Box(
                                            modifier = Modifier
                                                .size(28.dp)
                                                .clip(CircleShape)
                                                .background(color)
                                                .border(
                                                    width = if (brushColor == color && !isEraser) 3.dp else 1.dp,
                                                    color = if (brushColor == color && !isEraser) MaterialTheme.colorScheme.primary else Color.Gray,
                                                    shape = CircleShape
                                                )
                                                .clickable {
                                                    brushColor = color
                                                    isEraser = false
                                                }
                                        )
                                    }

                                    FilterChip(
                                        selected = isEraser,
                                        onClick = { isEraser = !isEraser },
                                        label = { Text("Eraser") }
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Text("Brush Size: ${brushSize.toInt()} px", style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = brushSize,
                                    onValueChange = { brushSize = it },
                                    valueRange = 2f..30f
                                )
                            }

                            ImageEditorTab.TEXT_WATERMARK -> {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("Text & Watermark", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                                    Button(
                                        onClick = { showAddTextDialog = true },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                                    ) {
                                        Text("Add Text Stamp", fontSize = 11.sp)
                                    }
                                }

                                OutlinedTextField(
                                    value = watermarkText,
                                    onValueChange = { watermarkText = it },
                                    label = { Text("Watermark text") },
                                    placeholder = { Text("e.g. Created by Bhaskar") },
                                    modifier = Modifier.fillMaxWidth()
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text("Watermark Opacity: ${(watermarkOpacity * 100).toInt()}%", style = MaterialTheme.typography.labelSmall)
                                Slider(
                                    value = watermarkOpacity,
                                    onValueChange = { watermarkOpacity = it },
                                    valueRange = 0.1f..1.0f
                                )
                            }

                            ImageEditorTab.EXPORT -> {
                                Text("Export Format", style = MaterialTheme.typography.labelSmall)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    listOf("jpg", "png", "webp", "bmp").forEach { fmt ->
                                        FilterChip(
                                            selected = exportFormat == fmt,
                                            onClick = { exportFormat = fmt },
                                            label = { Text(fmt.uppercase()) }
                                        )
                                    }
                                }

                                if (exportFormat in listOf("jpg", "webp")) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text("Quality: $exportQuality%", style = MaterialTheme.typography.labelSmall)
                                    Slider(
                                        value = exportQuality.toFloat(),
                                        onValueChange = { exportQuality = it.toInt() },
                                        valueRange = 10f..100f
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Text Dialog
    if (showAddTextDialog) {
        AlertDialog(
            onDismissRequest = { showAddTextDialog = false },
            title = { Text("Add Text Overlay") },
            text = {
                OutlinedTextField(
                    value = textToAdd,
                    onValueChange = { textToAdd = it },
                    label = { Text("Overlay Text") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (textToAdd.isNotBlank()) {
                            textItems.add(
                                ImageTextItem(
                                    text = textToAdd,
                                    x = 50f,
                                    y = 100f,
                                    color = AndroidColor.WHITE,
                                    textSize = 36f
                                )
                            )
                            textToAdd = ""
                            showAddTextDialog = false
                        }
                    }
                ) {
                    Text("Add")
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTextDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Success Dialog
    if (exportedFile != null) {
        val file = exportedFile!!
        AlertDialog(
            onDismissRequest = { exportedFile = null },
            icon = { Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary) },
            title = { Text("Image Exported Successfully") },
            text = {
                Column {
                    Text("File: ${file.name}")
                    Text("Size: ${(file.length() / 1024)} KB")
                    Text("Saved to workspace. 100% processed locally on device.")
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (onSaveToDownloads != null) {
                        Button(onClick = { onSaveToDownloads(file) }) {
                            Text("Download")
                        }
                    }
                    Button(onClick = { onOpenFile(file) }) {
                        Text("Open")
                    }
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { onShareFile(file) }) {
                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Share")
                }
            }
        )
    }
}
