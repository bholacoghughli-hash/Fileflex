package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.localization.AppLanguage
import com.example.localization.StringsProvider
import com.example.model.ConversionOptions
import com.example.model.FileCategory
import com.example.model.FileFormat

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ConversionOptionsPanel(
    category: FileCategory,
    targetFormat: FileFormat,
    options: ConversionOptions,
    language: AppLanguage,
    onOptionsChanged: (ConversionOptions) -> Unit,
    modifier: Modifier = Modifier
) {
    var expanded by remember { mutableStateOf(false) }

    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
        tonalElevation = 1.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header Toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { expanded = !expanded }
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Tune,
                        contentDescription = "Options",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = StringsProvider.get("conversion_options", language),
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Icon(
                    imageVector = if (expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = if (expanded) "Collapse" else "Expand",
                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            AnimatedVisibility(
                visible = expanded,
                enter = fadeIn() + expandVertically(),
                exit = fadeOut() + shrinkVertically()
            ) {
                Column(modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {

                    // IMAGE SPECIFIC OPTIONS
                    if (category == FileCategory.IMAGE && targetFormat.extension in listOf("jpg", "jpeg", "webp", "bmp")) {
                        // Quality Slider
                        Text(
                            text = "${StringsProvider.get("quality", language)}: ${options.imageQuality}%",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Medium),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Slider(
                            value = options.imageQuality.toFloat(),
                            onValueChange = { onOptionsChanged(options.copy(imageQuality = it.toInt())) },
                            valueRange = 10f..100f,
                            steps = 17,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        // Resize Percentage Chips
                        Text(
                            text = StringsProvider.get("resize", language),
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Medium),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        FlowRow(
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(100 to "100% (Original)", 75 to "75%", 50 to "50%", 25 to "25%").forEach { (pct, label) ->
                                FilterChip(
                                    selected = options.resizePercentage == pct,
                                    onClick = { onOptionsChanged(options.copy(resizePercentage = pct)) },
                                    label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }

                        // Remove Transparency Switch
                        if (targetFormat.extension in listOf("jpg", "jpeg", "bmp")) {
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = StringsProvider.get("remove_transparency", language),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f)
                                )
                                Switch(
                                    checked = options.removeTransparency,
                                    onCheckedChange = { onOptionsChanged(options.copy(removeTransparency = it)) }
                                )
                            }
                        }
                    }

                    // DOCUMENT / PDF SPECIFIC OPTIONS
                    if (targetFormat.extension == "pdf") {
                        Text(
                            text = StringsProvider.get("page_size", language),
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Medium),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        FlowRow(
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("A4", "Letter", "Legal", "Auto").forEach { size ->
                                FilterChip(
                                    selected = options.pdfPageSize == size,
                                    onClick = { onOptionsChanged(options.copy(pdfPageSize = size)) },
                                    label = { Text(size, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = StringsProvider.get("orientation", language),
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Medium),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        FlowRow(
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("Portrait", "Landscape").forEach { orient ->
                                FilterChip(
                                    selected = options.pdfOrientation == orient,
                                    onClick = { onOptionsChanged(options.copy(pdfOrientation = orient)) },
                                    label = { Text(orient, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }

                        if (category == FileCategory.IMAGE) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = StringsProvider.get("fit_mode", language),
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Medium),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            FlowRow(
                                modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("Fit" to "Fit Page", "CenterCrop" to "Center Crop", "Fill" to "Stretch").forEach { (mode, label) ->
                                    FilterChip(
                                        selected = options.pdfFitMode == mode,
                                        onClick = { onOptionsChanged(options.copy(pdfFitMode = mode)) },
                                        label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }
                        }
                    }

                    // AUDIO SPECIFIC OPTIONS
                    if (category == FileCategory.AUDIO || (category == FileCategory.VIDEO && targetFormat.extension == "wav")) {
                        Text(
                            text = StringsProvider.get("sample_rate", language),
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Medium),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        FlowRow(
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(44100 to "44.1 kHz (CD)", 48000 to "48.0 kHz (Studio)", 22050 to "22.0 kHz (Low)").forEach { (sr, label) ->
                                FilterChip(
                                    selected = options.audioSampleRate == sr,
                                    onClick = { onOptionsChanged(options.copy(audioSampleRate = sr)) },
                                    label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }
                    }

                    // VIDEO FRAME EXTRACTION OPTIONS
                    if (category == FileCategory.VIDEO && targetFormat.extension in listOf("jpg", "png", "webp")) {
                        Text(
                            text = "${StringsProvider.get("keyframe_second", language)}: ${options.videoKeyframeSecond}s",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Medium),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Slider(
                            value = options.videoKeyframeSecond.toFloat(),
                            onValueChange = { onOptionsChanged(options.copy(videoKeyframeSecond = it.toInt())) },
                            valueRange = 0f..60f,
                            steps = 59,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
    }
}
