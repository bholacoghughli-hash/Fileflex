package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Colors
val IndigoPrimaryLight = Color(0xFF4338CA)
val IndigoOnPrimaryLight = Color(0xFFFFFFFF)
val IndigoContainerLight = Color(0xFFEEF2FF)
val IndigoOnContainerLight = Color(0xFF312E81)

val CyanSecondaryLight = Color(0xFF0284C7)
val CyanOnSecondaryLight = Color(0xFFFFFFFF)
val CyanContainerLight = Color(0xFFE0F2FE)
val CyanOnContainerLight = Color(0xFF0369A1)

val EmeraldTertiaryLight = Color(0xFF059669)
val EmeraldOnTertiaryLight = Color(0xFFFFFFFF)
val EmeraldContainerLight = Color(0xFFD1FAE5)
val EmeraldOnContainerLight = Color(0xFF065F46)

val BackgroundLight = Color(0xFFF8FAFC)
val OnBackgroundLight = Color(0xFF0F172A)
val SurfaceLight = Color(0xFFFFFFFF)
val OnSurfaceLight = Color(0xFF0F172A)
val SurfaceVariantLight = Color(0xFFF1F5F9)
val OnSurfaceVariantLight = Color(0xFF475569)
val OutlineLight = Color(0xFFCBD5E1)

// Dark Theme Colors
val IndigoPrimaryDark = Color(0xFF818CF8)
val IndigoOnPrimaryDark = Color(0xFF1E1B4B)
val IndigoContainerDark = Color(0xFF312E81)
val IndigoOnContainerDark = Color(0xFFE0E7FF)

val CyanSecondaryDark = Color(0xFF38BDF8)
val CyanOnSecondaryDark = Color(0xFF082F49)
val CyanContainerDark = Color(0xFF0369A1)
val CyanOnContainerDark = Color(0xFFBAE6FD)

val EmeraldTertiaryDark = Color(0xFF34D399)
val EmeraldOnTertiaryDark = Color(0xFF064E3B)
val EmeraldContainerDark = Color(0xFF065F46)
val EmeraldOnContainerDark = Color(0xFFA7F3D0)

val BackgroundDark = Color(0xFF0B0F19)
val OnBackgroundDark = Color(0xFFF8FAFC)
val SurfaceDark = Color(0xFF131B2E)
val OnSurfaceDark = Color(0xFFF8FAFC)
val SurfaceVariantDark = Color(0xFF1E293B)
val OnSurfaceVariantDark = Color(0xFF94A3B8)
val OutlineDark = Color(0xFF334155)

// Status / Accent Colors
val SuccessGreen = Color(0xFF10B981)
val WarningAmber = Color(0xFFF59E0B)
val ErrorRose = Color(0xFFF43F5E)
