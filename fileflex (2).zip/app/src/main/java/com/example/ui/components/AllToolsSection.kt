package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.localization.AppLanguage
import com.example.model.FileCategory
import com.example.viewmodel.EditorType

data class FunctionalToolItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val category: FileCategory,
    val icon: ImageVector,
    val accentColor: Color,
    val actionText: String,
    val onAction: () -> Unit
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AllToolsSection(
    language: AppLanguage,
    onOpenEditor: (EditorType) -> Unit,
    onPickSingleFile: () -> Unit,
    onPickMultipleFiles: () -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedCategory by remember { mutableStateOf<FileCategory?>(null) }

    val allTools = remember(language) {
        listOf(
            // IMAGE TOOLS
            FunctionalToolItem(
                id = "img_conv",
                title = "Image Converter",
                subtitle = "Convert JPG, PNG, WebP, BMP, ICO & PDF",
                category = FileCategory.IMAGE,
                icon = Icons.Default.Transform,
                accentColor = Color(0xFF3B82F6),
                actionText = "Convert",
                onAction = onPickSingleFile
            ),
            FunctionalToolItem(
                id = "img_edit",
                title = "Image Editor & Retouch",
                subtitle = "Crop, Resize, Rotate, Filters, Watermark & Draw",
                category = FileCategory.IMAGE,
                icon = Icons.Default.Image,
                accentColor = Color(0xFF06B6D4),
                actionText = "Open Editor",
                onAction = { onOpenEditor(EditorType.IMAGE) }
            ),
            FunctionalToolItem(
                id = "img_to_pdf",
                title = "Photos → PDF Generator",
                subtitle = "Combine multiple images into one clean PDF",
                category = FileCategory.IMAGE,
                icon = Icons.Default.PictureAsPdf,
                accentColor = Color(0xFF6366F1),
                actionText = "Select Photos",
                onAction = onPickMultipleFiles
            ),

            // PDF TOOLS
            FunctionalToolItem(
                id = "pdf_annotator",
                title = "PDF Editor & Annotator",
                subtitle = "Sign, Highlight, Draw, Add Text & Organize Pages",
                category = FileCategory.DOCUMENT,
                icon = Icons.Default.PictureAsPdf,
                accentColor = Color(0xFFEF4444),
                actionText = "Open PDF Editor",
                onAction = { onOpenEditor(EditorType.PDF) }
            ),
            FunctionalToolItem(
                id = "pdf_to_images",
                title = "PDF → High-Res Images",
                subtitle = "Render and extract PDF pages as JPG or PNG",
                category = FileCategory.DOCUMENT,
                icon = Icons.Default.Image,
                accentColor = Color(0xFFF97316),
                actionText = "Extract Pages",
                onAction = onPickSingleFile
            ),
            FunctionalToolItem(
                id = "txt_to_pdf",
                title = "Document → Formatted PDF",
                subtitle = "Convert TXT, Markdown or HTML into formatted PDF",
                category = FileCategory.DOCUMENT,
                icon = Icons.Default.Description,
                accentColor = Color(0xFF10B981),
                actionText = "Convert Doc",
                onAction = onPickSingleFile
            ),

            // VIDEO TOOLS
            FunctionalToolItem(
                id = "vid_trimmer",
                title = "Video Trimmer & Splitter",
                subtitle = "Losslessly trim video start/end with visual slider",
                category = FileCategory.VIDEO,
                icon = Icons.Default.ContentCut,
                accentColor = Color(0xFFEC4899),
                actionText = "Trim Video",
                onAction = { onOpenEditor(EditorType.VIDEO) }
            ),
            FunctionalToolItem(
                id = "vid_extract_audio",
                title = "Extract Audio from Video",
                subtitle = "Demux video soundtrack into WAV or M4A",
                category = FileCategory.VIDEO,
                icon = Icons.Default.Audiotrack,
                accentColor = Color(0xFF8B5CF6),
                actionText = "Extract Audio",
                onAction = onPickSingleFile
            ),
            FunctionalToolItem(
                id = "vid_frame_grabber",
                title = "Video Keyframe Snapshot",
                subtitle = "Capture full-resolution frame as JPG/PNG",
                category = FileCategory.VIDEO,
                icon = Icons.Default.Videocam,
                accentColor = Color(0xFFF43F5E),
                actionText = "Capture Frame",
                onAction = { onOpenEditor(EditorType.VIDEO) }
            ),

            // AUDIO TOOLS
            FunctionalToolItem(
                id = "audio_editor",
                title = "Audio Editor & Trimmer",
                subtitle = "Waveform visualizer, trim, gain & fade effects",
                category = FileCategory.AUDIO,
                icon = Icons.Default.Tune,
                accentColor = Color(0xFF14B8A6),
                actionText = "Open Audio Editor",
                onAction = { onOpenEditor(EditorType.AUDIO) }
            ),
            FunctionalToolItem(
                id = "audio_converter",
                title = "Audio Transcoder (→ WAV/M4A)",
                subtitle = "Convert MP3, AAC, OGG, FLAC to Lossless WAV",
                category = FileCategory.AUDIO,
                icon = Icons.Default.Audiotrack,
                accentColor = Color(0xFF0EA5E9),
                actionText = "Convert Audio",
                onAction = onPickSingleFile
            ),

            // DOCUMENT TOOLS
            FunctionalToolItem(
                id = "doc_editor",
                title = "Document Editor & Exporter",
                subtitle = "Draft and edit TXT, HTML, JSON & export to PDF",
                category = FileCategory.DOCUMENT,
                icon = Icons.Default.Edit,
                accentColor = Color(0xFF10B981),
                actionText = "Open Doc Editor",
                onAction = { onOpenEditor(EditorType.DOCUMENT) }
            ),

            // ARCHIVE TOOLS
            FunctionalToolItem(
                id = "zip_creator",
                title = "ZIP Creator & Compressor",
                subtitle = "Pack multiple files into compressed .ZIP",
                category = FileCategory.ARCHIVE,
                icon = Icons.Default.FolderZip,
                accentColor = Color(0xFFF59E0B),
                actionText = "Create ZIP",
                onAction = { onOpenEditor(EditorType.ZIP) }
            ),
            FunctionalToolItem(
                id = "zip_extractor",
                title = "ZIP Inspector & Extractor",
                subtitle = "Inspect archive entries and extract files locally",
                category = FileCategory.ARCHIVE,
                icon = Icons.Default.FolderZip,
                accentColor = Color(0xFFD97706),
                actionText = "Open ZIP",
                onAction = { onOpenEditor(EditorType.ZIP) }
            )
        )
    }

    val filteredTools = if (selectedCategory == null) {
        allTools
    } else {
        allTools.filter { it.category == selectedCategory }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 12.dp)
            .testTag("all_tools_section")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Build,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (language == AppLanguage.HINDI) "सभी टूल्स (All Tools)" else "All Working Tools",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
            Text(
                text = "${filteredTools.size} Tools",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.primary
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Category Filter Chips
        val categories = listOf(
            null to (if (language == AppLanguage.HINDI) "सभी (All)" else "All"),
            FileCategory.IMAGE to "IMAGE",
            FileCategory.DOCUMENT to "PDF / DOC",
            FileCategory.VIDEO to "VIDEO",
            FileCategory.AUDIO to "AUDIO",
            FileCategory.ARCHIVE to "ARCHIVE"
        )

        LazyRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(categories) { (cat, label) ->
                val isSelected = selectedCategory == cat
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedCategory = cat },
                    label = {
                        Text(
                            text = label,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                        )
                    },
                    colors = FilterChipDefaults.filterChipColors(
                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                        selectedLabelColor = Color.White
                    ),
                    shape = RoundedCornerShape(10.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Grid of Real Working Tools
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            filteredTools.forEach { tool ->
                FunctionalToolCard(tool = tool)
            }
        }
    }
}

@Composable
private fun FunctionalToolCard(
    tool: FunctionalToolItem,
    modifier: Modifier = Modifier
) {
    ElevatedCard(
        modifier = modifier
            .fillMaxWidth()
            .testTag("tool_card_${tool.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = androidx.compose.material3.CardDefaults.elevatedCardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(tool.accentColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = tool.icon,
                    contentDescription = null,
                    tint = tool.accentColor,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(14.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = tool.title,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 1
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = tool.accentColor.copy(alpha = 0.12f)
                    ) {
                        Text(
                            text = tool.category.name,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = tool.accentColor
                            ),
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = tool.subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Button(
                onClick = tool.onAction,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = tool.accentColor
                ),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = tool.actionText,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}
