package com.example.engine

import com.example.model.FileCategory
import com.example.model.FileFormat

data class CapabilityCheckResult(
    val isSupported: Boolean,
    val reason: String? = null
)

object EngineCapabilityChecker {

    // Maximum safe file sizes for local processing to prevent OOM
    const val MAX_IMAGE_SIZE_BYTES = 80 * 1024 * 1024L // 80 MB
    const val MAX_GENERAL_SIZE_BYTES = 350 * 1024 * 1024L // 350 MB

    fun checkFileSize(category: FileCategory, sizeBytes: Long): CapabilityCheckResult {
        val limit = when (category) {
            FileCategory.IMAGE -> MAX_IMAGE_SIZE_BYTES
            else -> MAX_GENERAL_SIZE_BYTES
        }
        return if (sizeBytes > limit) {
            CapabilityCheckResult(
                isSupported = false,
                reason = "This file is too large for reliable processing. Try a smaller file."
            )
        } else {
            CapabilityCheckResult(isSupported = true)
        }
    }

    fun checkConversion(
        inputCategory: FileCategory,
        inputExt: String,
        targetExt: String
    ): CapabilityCheckResult {
        val src = inputExt.lowercase().trim()
        val dst = targetExt.lowercase().trim()

        if (src == dst) {
            return CapabilityCheckResult(
                isSupported = false,
                reason = "Source and target formats are identical ($src)."
            )
        }

        // Archive is universally supported for any file
        if (dst == "zip") {
            return CapabilityCheckResult(isSupported = true)
        }

        when (inputCategory) {
            FileCategory.IMAGE -> {
                val validImageTargets = listOf("jpg", "jpeg", "png", "webp", "bmp", "ico", "pdf")
                if (dst in validImageTargets) {
                    return CapabilityCheckResult(isSupported = true)
                }
                return CapabilityCheckResult(
                    isSupported = false,
                    reason = "This conversion is not supported by the current processing engine. Images can be converted to JPG, PNG, WEBP, BMP, ICO, PDF, or ZIP."
                )
            }

            FileCategory.DOCUMENT -> {
                when (src) {
                    "pdf" -> {
                        if (dst in listOf("jpg", "jpeg", "png", "webp")) {
                            return CapabilityCheckResult(isSupported = true)
                        }
                        return CapabilityCheckResult(
                            isSupported = false,
                            reason = "This conversion is not supported by the current processing engine. PDF pages can be rendered to JPG, PNG, WEBP, or packaged in ZIP."
                        )
                    }
                    "txt", "csv", "log", "json", "md" -> {
                        if (dst in listOf("pdf", "html")) {
                            return CapabilityCheckResult(isSupported = true)
                        }
                        return CapabilityCheckResult(
                            isSupported = false,
                            reason = "This conversion is not supported by the current processing engine. Text documents can be formatted to PDF or HTML."
                        )
                    }
                    "html", "htm" -> {
                        if (dst in listOf("pdf", "txt")) {
                            return CapabilityCheckResult(isSupported = true)
                        }
                        return CapabilityCheckResult(
                            isSupported = false,
                            reason = "This conversion is not supported by the current processing engine. HTML can be rendered to PDF or extracted to TXT."
                        )
                    }
                    else -> {
                        return CapabilityCheckResult(
                            isSupported = false,
                            reason = "This conversion is not supported by the current processing engine."
                        )
                    }
                }
            }

            FileCategory.AUDIO -> {
                // Audio conversion: Native MediaCodec decodes to PCM (WAV) or encodes to AAC (.m4a)
                if (dst in listOf("wav", "m4a")) {
                    return CapabilityCheckResult(isSupported = true)
                }
                if (dst == "mp3") {
                    return CapabilityCheckResult(
                        isSupported = false,
                        reason = "This conversion is not supported by the current processing engine. Native Android engine encodes audio to lossless WAV or AAC (M4A). MP3 encoding is not natively supported."
                    )
                }
                return CapabilityCheckResult(
                    isSupported = false,
                    reason = "This conversion is not supported by the current processing engine."
                )
            }

            FileCategory.VIDEO -> {
                // Video extraction: Audio stream to WAV/M4A, Keyframe to JPG/PNG/WEBP
                if (dst in listOf("wav", "m4a", "jpg", "jpeg", "png", "webp")) {
                    return CapabilityCheckResult(isSupported = true)
                }
                return CapabilityCheckResult(
                    isSupported = false,
                    reason = "This conversion is not supported by the current processing engine. Video supports audio soundtrack extraction (WAV/M4A) and frame capture (JPG/PNG/WEBP)."
                )
            }

            FileCategory.ARCHIVE -> {
                if (dst == "zip") {
                    return CapabilityCheckResult(isSupported = true)
                }
                return CapabilityCheckResult(
                    isSupported = false,
                    reason = "This conversion is not supported by the current processing engine. Archives can be inspected or repackaged to ZIP."
                )
            }

            FileCategory.OTHER -> {
                if (dst == "zip") {
                    return CapabilityCheckResult(isSupported = true)
                }
                return CapabilityCheckResult(
                    isSupported = false,
                    reason = "This conversion is not supported by the current processing engine."
                )
            }
        }
    }
}
