package com.example.engine

import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStreamReader

object DocumentEditEngine {

    suspend fun readTextFromUri(context: Context, uri: Uri): String = withContext(Dispatchers.IO) {
        context.contentResolver.openInputStream(uri)?.use { stream ->
            InputStreamReader(stream, Charsets.UTF_8).use { reader ->
                reader.readText()
            }
        } ?: ""
    }

    suspend fun readTextFromFile(file: File): String = withContext(Dispatchers.IO) {
        if (!file.exists()) "" else file.readText(Charsets.UTF_8)
    }

    suspend fun saveTextToFile(text: String, outputFile: File): File = withContext(Dispatchers.IO) {
        outputFile.writeText(text, Charsets.UTF_8)
        outputFile
    }

    /**
     * Converts raw text or markdown into a formatted multi-page PDF document.
     */
    suspend fun exportTextToPdf(
        text: String,
        title: String,
        outputFile: File,
        onProgress: (Float) -> Unit
    ): File = withContext(Dispatchers.IO) {
        onProgress(0.1f)
        val document = PdfDocument()

        val pageWidth = 595 // A4 standard pt
        val pageHeight = 842
        val margin = 50f
        val contentWidth = pageWidth - (margin * 2)

        val textPaint = Paint().apply {
            color = Color.BLACK
            textSize = 12f
            isAntiAlias = true
        }

        val titlePaint = Paint().apply {
            color = Color.parseColor("#1E293B")
            textSize = 18f
            isFakeBoldText = true
            isAntiAlias = true
        }

        val footerPaint = Paint().apply {
            color = Color.GRAY
            textSize = 9f
            isAntiAlias = true
        }

        val lineHeight = 18f
        val lines = mutableListOf<String>()

        // Word wrap text into lines fitting contentWidth
        val rawParagraphs = text.split("\n")
        for (para in rawParagraphs) {
            if (para.isBlank()) {
                lines.add("")
                continue
            }
            val words = para.split(" ")
            var currentLine = StringBuilder()

            for (word in words) {
                val candidate = if (currentLine.isEmpty()) word else "${currentLine} $word"
                if (textPaint.measureText(candidate) <= contentWidth) {
                    currentLine = StringBuilder(candidate)
                } else {
                    if (currentLine.isNotEmpty()) {
                        lines.add(currentLine.toString())
                    }
                    currentLine = StringBuilder(word)
                }
            }
            if (currentLine.isNotEmpty()) {
                lines.add(currentLine.toString())
            }
        }

        val linesPerPage = ((pageHeight - (margin * 2) - 40f) / lineHeight).toInt().coerceAtLeast(1)
        val totalPages = (lines.size + linesPerPage - 1) / linesPerPage.coerceAtLeast(1)
        val effectiveTotal = if (totalPages == 0) 1 else totalPages

        var lineIndex = 0
        for (pageNum in 1..effectiveTotal) {
            val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, pageNum).create()
            val page = document.startPage(pageInfo)
            val canvas = page.canvas

            var y = margin + 20f

            // If first page, draw title
            if (pageNum == 1) {
                canvas.drawText(title, margin, y, titlePaint)
                y += 30f
            }

            var linesDrawn = 0
            while (lineIndex < lines.size && linesDrawn < linesPerPage) {
                val line = lines[lineIndex++]
                canvas.drawText(line, margin, y, textPaint)
                y += lineHeight
                linesDrawn++
            }

            // Draw footer
            val footerText = "Page $pageNum of $effectiveTotal • Created by Bhaskar Gautam"
            canvas.drawText(footerText, margin, pageHeight - 30f, footerPaint)

            document.finishPage(page)
            onProgress((pageNum.toFloat() / effectiveTotal.toFloat()).coerceIn(0.1f, 0.95f))
        }

        FileOutputStream(outputFile).use { fos ->
            document.writeTo(fos)
        }
        document.close()
        onProgress(1.0f)
        outputFile
    }
}
