package com.example.engine

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

data class PdfPageAnnotation(
    val id: String = java.util.UUID.randomUUID().toString(),
    val pageIndex: Int,
    val type: AnnotationType,
    val text: String = "",
    val color: Int = Color.BLACK,
    val textSize: Float = 18f,
    val x: Float = 50f,
    val y: Float = 100f,
    val strokeWidth: Float = 4f,
    val points: List<Pair<Float, Float>> = emptyList(), // For freehand drawing & highlights
    val rect: RectF? = null // For shapes or highlight boxes
)

enum class AnnotationType {
    TEXT,
    DRAWING,
    HIGHLIGHT,
    RECTANGLE,
    SIGNATURE
}

data class PdfPageSpec(
    val originalPageIndex: Int,
    val rotationDegrees: Int = 0, // 0, 90, 180, 270
    val isDeleted: Boolean = false
)

object PdfEditEngine {

    /**
     * Copies a content URI to a temporary local cache file so that ParcelFileDescriptor can open it.
     */
    fun copyUriToLocalCache(context: Context, uri: Uri): File {
        val tempFile = File(context.cacheDir, "pdf_edit_temp_${System.currentTimeMillis()}.pdf")
        context.contentResolver.openInputStream(uri)?.use { input ->
            FileOutputStream(tempFile).use { output ->
                input.copyTo(output)
            }
        } ?: throw IllegalArgumentException("Cannot read input PDF")
        return tempFile
    }

    /**
     * Gets the total number of pages in a PDF file.
     */
    fun getPageCount(pdfFile: File): Int {
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        return try {
            pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd)
            renderer.pageCount
        } catch (e: Exception) {
            0
        } finally {
            try { renderer?.close() } catch (_: Exception) {}
            try { pfd?.close() } catch (_: Exception) {}
        }
    }

    /**
     * Renders a specific page into a Bitmap for display or thumbnail.
     */
    fun renderPageToBitmap(
        pdfFile: File,
        pageIndex: Int,
        targetWidth: Int = 1000,
        rotationDegrees: Int = 0
    ): Bitmap? {
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        var page: PdfRenderer.Page? = null
        return try {
            pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd)
            if (pageIndex < 0 || pageIndex >= renderer.pageCount) return null

            page = renderer.openPage(pageIndex)
            val aspect = page.height.toFloat() / page.width.toFloat()
            val finalWidth = targetWidth.coerceIn(200, 2400)
            val finalHeight = (finalWidth * aspect).toInt().coerceAtLeast(200)

            val bitmap = Bitmap.createBitmap(finalWidth, finalHeight, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.WHITE)

            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)

            if (rotationDegrees % 360 != 0) {
                val matrix = android.graphics.Matrix().apply {
                    postRotate(rotationDegrees.toFloat())
                }
                val rotated = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
                if (rotated != bitmap) bitmap.recycle()
                rotated
            } else {
                bitmap
            }
        } catch (e: Exception) {
            null
        } finally {
            try { page?.close() } catch (_: Exception) {}
            try { renderer?.close() } catch (_: Exception) {}
            try { pfd?.close() } catch (_: Exception) {}
        }
    }

    /**
     * Saves the modified PDF with reordered, rotated, duplicated, or deleted pages,
     * and bakes in all text, drawing, highlight, shape, and signature annotations.
     */
    suspend fun exportEditedPdf(
        pdfFile: File,
        pageSpecs: List<PdfPageSpec>,
        annotations: List<PdfPageAnnotation>,
        outputFile: File,
        onProgress: (Float) -> Unit
    ): File = withContext(Dispatchers.IO) {
        onProgress(0.05f)
        val validSpecs = pageSpecs.filter { !it.isDeleted }
        if (validSpecs.isEmpty()) throw IllegalArgumentException("Cannot export empty PDF")

        val document = PdfDocument()
        val total = validSpecs.size

        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null

        try {
            pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd)

            for ((outIdx, spec) in validSpecs.withIndex()) {
                val origIdx = spec.originalPageIndex.coerceIn(0, renderer.pageCount - 1)
                val page = renderer.openPage(origIdx)

                val origW = page.width
                val origH = page.height
                val isRotated90 = (spec.rotationDegrees % 180 != 0)
                val outW = if (isRotated90) origH else origW
                val outH = if (isRotated90) origW else origH

                // Render source page into bitmap
                val pageBitmap = Bitmap.createBitmap(origW, origH, Bitmap.Config.ARGB_8888)
                val bmpCanvas = Canvas(pageBitmap)
                bmpCanvas.drawColor(Color.WHITE)
                page.render(pageBitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()

                // Create new PdfDocument Page
                val pageInfo = PdfDocument.PageInfo.Builder(outW, outH, outIdx + 1).create()
                val docPage = document.startPage(pageInfo)
                val docCanvas = docPage.canvas

                // Draw base page with rotation
                if (spec.rotationDegrees % 360 != 0) {
                    docCanvas.save()
                    docCanvas.translate(outW / 2f, outH / 2f)
                    docCanvas.rotate(spec.rotationDegrees.toFloat())
                    docCanvas.drawBitmap(pageBitmap, -origW / 2f, -origH / 2f, null)
                    docCanvas.restore()
                } else {
                    docCanvas.drawBitmap(pageBitmap, 0f, 0f, null)
                }
                pageBitmap.recycle()

                // Draw Annotations for this page
                val pageAnnotations = annotations.filter { it.pageIndex == outIdx || it.pageIndex == spec.originalPageIndex }
                for (annot in pageAnnotations) {
                    drawAnnotation(docCanvas, annot)
                }

                document.finishPage(docPage)
                onProgress(0.1f + 0.8f * (outIdx + 1) / total)
            }

            FileOutputStream(outputFile).use { fos ->
                document.writeTo(fos)
            }
        } finally {
            try { renderer?.close() } catch (_: Exception) {}
            try { pfd?.close() } catch (_: Exception) {}
            try { document.close() } catch (_: Exception) {}
        }

        onProgress(1.0f)
        outputFile
    }

    private fun drawAnnotation(canvas: Canvas, annotation: PdfPageAnnotation) {
        when (annotation.type) {
            AnnotationType.TEXT -> {
                val paint = Paint().apply {
                    color = annotation.color
                    textSize = annotation.textSize
                    isAntiAlias = true
                }
                canvas.drawText(annotation.text, annotation.x, annotation.y, paint)
            }
            AnnotationType.DRAWING, AnnotationType.SIGNATURE -> {
                if (annotation.points.size > 1) {
                    val paint = Paint().apply {
                        color = annotation.color
                        strokeWidth = annotation.strokeWidth
                        style = Paint.Style.STROKE
                        strokeCap = Paint.Cap.ROUND
                        strokeJoin = Paint.Join.ROUND
                        isAntiAlias = true
                    }
                    val path = android.graphics.Path()
                    val first = annotation.points.first()
                    path.moveTo(first.first, first.second)
                    for (i in 1 until annotation.points.size) {
                        val pt = annotation.points[i]
                        path.lineTo(pt.first, pt.second)
                    }
                    canvas.drawPath(path, paint)
                }
            }
            AnnotationType.HIGHLIGHT -> {
                val paint = Paint().apply {
                    color = annotation.color
                    alpha = 100 // semi-transparent
                    style = Paint.Style.FILL
                    isAntiAlias = true
                }
                if (annotation.rect != null) {
                    canvas.drawRect(annotation.rect, paint)
                } else if (annotation.points.size > 1) {
                    paint.style = Paint.Style.STROKE
                    paint.strokeWidth = annotation.strokeWidth.coerceAtLeast(20f)
                    paint.strokeCap = Paint.Cap.SQUARE
                    val path = android.graphics.Path()
                    val first = annotation.points.first()
                    path.moveTo(first.first, first.second)
                    for (i in 1 until annotation.points.size) {
                        val pt = annotation.points[i]
                        path.lineTo(pt.first, pt.second)
                    }
                    canvas.drawPath(path, paint)
                }
            }
            AnnotationType.RECTANGLE -> {
                val paint = Paint().apply {
                    color = annotation.color
                    strokeWidth = annotation.strokeWidth
                    style = Paint.Style.STROKE
                    isAntiAlias = true
                }
                annotation.rect?.let { canvas.drawRect(it, paint) }
            }
        }
    }

    /**
     * Merges multiple PDF files into one combined PDF.
     */
    suspend fun mergePdfs(
        pdfFiles: List<File>,
        outputFile: File,
        onProgress: (Float) -> Unit
    ): File = withContext(Dispatchers.IO) {
        val document = PdfDocument()
        var pageCountOut = 0
        val totalFiles = pdfFiles.size

        for ((fileIdx, file) in pdfFiles.withIndex()) {
            var pfd: ParcelFileDescriptor? = null
            var renderer: PdfRenderer? = null
            try {
                pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                renderer = PdfRenderer(pfd)
                for (i in 0 until renderer.pageCount) {
                    val page = renderer.openPage(i)
                    val w = page.width
                    val h = page.height

                    val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    val canvas = Canvas(bitmap)
                    canvas.drawColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    page.close()

                    val pageInfo = PdfDocument.PageInfo.Builder(w, h, ++pageCountOut).create()
                    val docPage = document.startPage(pageInfo)
                    docPage.canvas.drawBitmap(bitmap, 0f, 0f, null)
                    document.finishPage(docPage)
                    bitmap.recycle()
                }
            } finally {
                try { renderer?.close() } catch (_: Exception) {}
                try { pfd?.close() } catch (_: Exception) {}
            }
            onProgress((fileIdx + 1).toFloat() / totalFiles)
        }

        FileOutputStream(outputFile).use { fos ->
            document.writeTo(fos)
        }
        document.close()
        outputFile
    }

    /**
     * Splits a PDF file into individual pages or extracts specific pages.
     */
    suspend fun extractPagesToPdf(
        pdfFile: File,
        pagesToExtract: List<Int>, // 0-indexed
        outputFile: File,
        onProgress: (Float) -> Unit
    ): File = withContext(Dispatchers.IO) {
        val document = PdfDocument()
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null

        try {
            pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd)

            for ((idx, pageIndex) in pagesToExtract.withIndex()) {
                if (pageIndex in 0 until renderer.pageCount) {
                    val page = renderer.openPage(pageIndex)
                    val w = page.width
                    val h = page.height

                    val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                    val canvas = Canvas(bitmap)
                    canvas.drawColor(Color.WHITE)
                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    page.close()

                    val pageInfo = PdfDocument.PageInfo.Builder(w, h, idx + 1).create()
                    val docPage = document.startPage(pageInfo)
                    docPage.canvas.drawBitmap(bitmap, 0f, 0f, null)
                    document.finishPage(docPage)
                    bitmap.recycle()
                }
                onProgress((idx + 1).toFloat() / pagesToExtract.size)
            }

            FileOutputStream(outputFile).use { fos ->
                document.writeTo(fos)
            }
        } finally {
            try { renderer?.close() } catch (_: Exception) {}
            try { pfd?.close() } catch (_: Exception) {}
            try { document.close() } catch (_: Exception) {}
        }
        outputFile
    }

    /**
     * Exports PDF pages as individual image files (JPG, PNG, WEBP).
     */
    suspend fun exportPagesAsImages(
        pdfFile: File,
        format: String, // "jpg", "png", "webp"
        destinationDir: File,
        baseName: String,
        onProgress: (Float) -> Unit
    ): List<File> = withContext(Dispatchers.IO) {
        val results = mutableListOf<File>()
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null

        try {
            pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY)
            renderer = PdfRenderer(pfd)
            val total = renderer.pageCount

            val ext = format.lowercase().trimStart('.')
            val compressFormat = when (ext) {
                "png" -> Bitmap.CompressFormat.PNG
                "webp" -> Bitmap.CompressFormat.WEBP
                else -> Bitmap.CompressFormat.JPEG
            }

            for (i in 0 until total) {
                val page = renderer.openPage(i)
                val w = page.width
                val h = page.height
                val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bitmap)
                canvas.drawColor(Color.WHITE)
                page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                page.close()

                val outFile = File(destinationDir, "${baseName}_page_${i + 1}.$ext")
                FileOutputStream(outFile).use { fos ->
                    bitmap.compress(compressFormat, 90, fos)
                }
                bitmap.recycle()
                results.add(outFile)
                onProgress((i + 1).toFloat() / total)
            }
        } finally {
            try { renderer?.close() } catch (_: Exception) {}
            try { pfd?.close() } catch (_: Exception) {}
        }
        results
    }
}
