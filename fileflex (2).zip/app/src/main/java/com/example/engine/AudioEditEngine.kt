package com.example.engine

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class AudioEditParams(
    val startMs: Long = 0L,
    val endMs: Long = 0L, // 0 = till end
    val volumeMultiplier: Float = 1.0f, // 0.5 to 2.0
    val fadeIn: Boolean = false,
    val fadeOut: Boolean = false,
    val exportFormat: String = "wav"
)

object AudioEditEngine {

    /**
     * Trims and adjusts volume of an audio file and saves as a clean standard WAV file.
     */
    suspend fun trimAndProcessAudio(
        context: Context,
        inputUri: Uri,
        params: AudioEditParams,
        outputFile: File,
        onProgress: (Float) -> Unit
    ): File = withContext(Dispatchers.IO) {
        onProgress(0.05f)

        val extractor = MediaExtractor()
        extractor.setDataSource(context, inputUri, null)

        var audioTrackIndex = -1
        var format: MediaFormat? = null

        for (i in 0 until extractor.trackCount) {
            val trackFormat = extractor.getTrackFormat(i)
            val mime = trackFormat.getString(MediaFormat.KEY_MIME) ?: ""
            if (mime.startsWith("audio/")) {
                audioTrackIndex = i
                format = trackFormat
                break
            }
        }

        if (audioTrackIndex == -1 || format == null) {
            extractor.release()
            throw IllegalArgumentException("No valid audio track found in media")
        }

        extractor.selectTrack(audioTrackIndex)

        val sampleRate = if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) format.getInteger(MediaFormat.KEY_SAMPLE_RATE) else 44100
        val channels = if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) else 2
        val totalDurationUs = if (format.containsKey(MediaFormat.KEY_DURATION)) format.getLong(MediaFormat.KEY_DURATION) else 0L

        val mime = format.getString(MediaFormat.KEY_MIME) ?: ""
        val decoder = MediaCodec.createDecoderByType(mime)
        decoder.configure(format, null, null, 0)
        decoder.start()

        val startUs = params.startMs * 1000L
        val endUs = if (params.endMs > 0 && params.endMs * 1000L > startUs) params.endMs * 1000L else totalDurationUs

        if (startUs > 0) {
            extractor.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
        }

        val tempPcmFile = File(context.cacheDir, "temp_trim_${System.currentTimeMillis()}.pcm")
        val pcmFos = FileOutputStream(tempPcmFile)

        val bufferInfo = MediaCodec.BufferInfo()
        var isEOS = false

        try {
            while (!isEOS) {
                val inputIndex = decoder.dequeueInputBuffer(10000)
                if (inputIndex >= 0) {
                    val inputBuffer = decoder.getInputBuffer(inputIndex)
                    if (inputBuffer != null) {
                        val sampleSize = extractor.readSampleData(inputBuffer, 0)
                        if (sampleSize < 0) {
                            decoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            isEOS = true
                        } else {
                            val presentationTimeUs = extractor.sampleTime
                            if (endUs > 0 && presentationTimeUs > endUs) {
                                decoder.queueInputBuffer(inputIndex, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                isEOS = true
                            } else {
                                decoder.queueInputBuffer(inputIndex, 0, sampleSize, presentationTimeUs, 0)
                                extractor.advance()
                            }
                        }
                    }
                }

                var outputIndex = decoder.dequeueOutputBuffer(bufferInfo, 10000)
                while (outputIndex >= 0) {
                    val outputBuffer = decoder.getOutputBuffer(outputIndex)
                    val outTimeUs = bufferInfo.presentationTimeUs

                    if (outputBuffer != null && bufferInfo.size > 0 && outTimeUs >= startUs) {
                        val chunk = ByteArray(bufferInfo.size)
                        outputBuffer.position(bufferInfo.offset)
                        outputBuffer.get(chunk, 0, bufferInfo.size)
                        pcmFos.write(chunk)
                    }
                    decoder.releaseOutputBuffer(outputIndex, false)

                    if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                        isEOS = true
                        break
                    }
                    outputIndex = decoder.dequeueOutputBuffer(bufferInfo, 0)
                }

                val currentUs = extractor.sampleTime
                if (totalDurationUs > 0 && currentUs > 0) {
                    val p = (currentUs.toFloat() / totalDurationUs.toFloat()).coerceIn(0f, 0.7f)
                    onProgress(p)
                }
            }
        } finally {
            pcmFos.flush()
            pcmFos.close()
            try { decoder.stop() } catch (_: Exception) {}
            try { decoder.release() } catch (_: Exception) {}
            try { extractor.release() } catch (_: Exception) {}
        }

        onProgress(0.8f)

        // Apply Gain & Fades to PCM data
        val pcmLength = tempPcmFile.length()
        val rawPcm = ByteArray(pcmLength.toInt())
        FileInputStream(tempPcmFile).use { it.read(rawPcm) }
        tempPcmFile.delete()

        val shortBuffer = ByteBuffer.wrap(rawPcm).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val totalSamples = shortBuffer.remaining()
        val fadeSamples = (sampleRate * channels * 1.5).toInt().coerceAtMost(totalSamples / 4) // 1.5s fade

        val processedPcm = ByteArray(rawPcm.size)
        val outShortBuffer = ByteBuffer.wrap(processedPcm).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()

        for (i in 0 until totalSamples) {
            var sample = shortBuffer.get(i).toFloat()

            // Apply gain
            sample *= params.volumeMultiplier

            // Apply Fade In
            if (params.fadeIn && i < fadeSamples) {
                val factor = i.toFloat() / fadeSamples.toFloat()
                sample *= factor
            }

            // Apply Fade Out
            if (params.fadeOut && i > totalSamples - fadeSamples) {
                val factor = (totalSamples - i).toFloat() / fadeSamples.toFloat()
                sample *= factor
            }

            val clamped = sample.coerceIn(-32768f, 32767f).toInt().toShort()
            outShortBuffer.put(clamped)
        }

        onProgress(0.9f)

        // Write WAV header and PCM audio data
        val fos = FileOutputStream(outputFile)
        val dataSize = processedPcm.size.toLong()
        val header = createWavHeader(dataSize, sampleRate, channels)
        fos.write(header)
        fos.write(processedPcm)
        fos.flush()
        fos.close()

        onProgress(1.0f)
        outputFile
    }

    private fun createWavHeader(dataSize: Long, sampleRate: Int, channels: Int): ByteArray {
        val totalSize = dataSize + 36
        val byteRate = sampleRate * channels * 2
        val blockAlign = channels * 2

        val buffer = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        buffer.put("RIFF".toByteArray())
        buffer.putInt(totalSize.toInt())
        buffer.put("WAVE".toByteArray())
        buffer.put("fmt ".toByteArray())
        buffer.putInt(16) // Subchunk1Size for PCM
        buffer.putShort(1) // AudioFormat (1 = PCM)
        buffer.putShort(channels.toShort())
        buffer.putInt(sampleRate)
        buffer.putInt(byteRate)
        buffer.putShort(blockAlign.toShort())
        buffer.putShort(16) // BitsPerSample
        buffer.put("data".toByteArray())
        buffer.putInt(dataSize.toInt())
        return buffer.array()
    }
}
