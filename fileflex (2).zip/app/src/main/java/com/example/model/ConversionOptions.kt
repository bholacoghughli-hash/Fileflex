package com.example.model

data class ConversionOptions(
    // Image options
    val imageQuality: Int = 85,
    val resizePercentage: Int = 100, // 25, 50, 75, 100
    val customWidth: Int? = null,
    val customHeight: Int? = null,
    val keepAspectRatio: Boolean = true,
    val removeTransparency: Boolean = false,
    val backgroundColor: Int = 0xFFFFFFFF.toInt(), // White default for alpha removal

    // Document / PDF options
    val pdfPageSize: String = "A4", // A4, Letter, Auto
    val pdfOrientation: String = "Portrait", // Portrait, Landscape, Auto
    val pdfMargin: String = "Normal", // None, Compact, Normal, Wide
    val pdfFitMode: String = "Fit", // Fit, CenterCrop, Fill

    // Audio options
    val audioSampleRate: Int = 44100, // 44100, 48000, 22050, 16000
    val audioChannels: Int = 2, // 1 (Mono), 2 (Stereo)
    val audioBitrateKbps: Int = 192,

    // Video options
    val videoKeyframeSecond: Int = 1,
    val videoFrameQuality: Int = 90
)

enum class JobStatus {
    WAITING,
    CONVERTING,
    COMPLETED,
    FAILED,
    CANCELLED
}

data class ConversionJob(
    val id: String = java.util.UUID.randomUUID().toString(),
    val fileInfo: FileInfo,
    val targetFormat: FileFormat,
    val options: ConversionOptions = ConversionOptions(),
    val status: JobStatus = JobStatus.WAITING,
    val progress: Float = 0f, // 0.0 to 1.0
    val statusMessage: String = "Ready",
    val convertedFile: java.io.File? = null,
    val convertedSizeBytes: Long = 0L,
    val durationMs: Long = 0L,
    val errorMessage: String? = null
) {
    val formattedConvertedSize: String
        get() {
            if (convertedSizeBytes <= 0) return "0 B"
            val units = arrayOf("B", "KB", "MB", "GB")
            var size = convertedSizeBytes.toDouble()
            var unitIndex = 0
            while (size >= 1024 && unitIndex < units.size - 1) {
                size /= 1024
                unitIndex++
            }
            return String.format(java.util.Locale.US, "%.1f %s", size, units[unitIndex])
        }

    val compressionSavingsPercentage: Int?
        get() {
            if (fileInfo.sizeBytes > 0 && convertedSizeBytes > 0) {
                val ratio = ((fileInfo.sizeBytes - convertedSizeBytes).toDouble() / fileInfo.sizeBytes.toDouble()) * 100
                return ratio.toInt()
            }
            return null
        }
}
