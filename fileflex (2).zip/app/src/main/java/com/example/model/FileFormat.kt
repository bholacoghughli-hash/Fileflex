package com.example.model

enum class FileCategory(val displayNameEn: String, val displayNameHi: String) {
    IMAGE("Image", "छवि"),
    DOCUMENT("Document", "दस्तावेज़"),
    AUDIO("Audio", "ऑडियो"),
    VIDEO("Video", "वीडियो"),
    ARCHIVE("Archive", "संग्रह (ZIP)"),
    OTHER("Other", "अन्य")
}

data class FileFormat(
    val extension: String,
    val name: String,
    val mimeType: String,
    val category: FileCategory,
    val isOutputSupported: Boolean = true
)

object SupportedFormats {
    val IMAGE_FORMATS = listOf(
        FileFormat("jpg", "JPEG Image", "image/jpeg", FileCategory.IMAGE),
        FileFormat("png", "PNG Image", "image/png", FileCategory.IMAGE),
        FileFormat("webp", "WebP Image", "image/webp", FileCategory.IMAGE),
        FileFormat("bmp", "Bitmap (BMP)", "image/bmp", FileCategory.IMAGE),
        FileFormat("ico", "Icon (ICO)", "image/x-icon", FileCategory.IMAGE),
        FileFormat("pdf", "PDF Document", "application/pdf", FileCategory.DOCUMENT)
    )

    val DOCUMENT_FORMATS = listOf(
        FileFormat("pdf", "PDF Document", "application/pdf", FileCategory.DOCUMENT),
        FileFormat("txt", "Plain Text", "text/plain", FileCategory.DOCUMENT),
        FileFormat("html", "HTML Webpage", "text/html", FileCategory.DOCUMENT),
        FileFormat("zip", "ZIP Archive", "application/zip", FileCategory.ARCHIVE)
    )

    val AUDIO_FORMATS = listOf(
        FileFormat("wav", "WAV (Lossless PCM)", "audio/wav", FileCategory.AUDIO),
        FileFormat("m4a", "M4A (AAC Audio)", "audio/mp4", FileCategory.AUDIO),
        FileFormat("zip", "ZIP Archive", "application/zip", FileCategory.ARCHIVE)
    )

    val VIDEO_FORMATS = listOf(
        FileFormat("wav", "Extract Audio (WAV)", "audio/wav", FileCategory.AUDIO),
        FileFormat("m4a", "Extract Audio (M4A)", "audio/mp4", FileCategory.AUDIO),
        FileFormat("jpg", "Extract Keyframe (JPG)", "image/jpeg", FileCategory.IMAGE),
        FileFormat("png", "Extract Keyframe (PNG)", "image/png", FileCategory.IMAGE),
        FileFormat("zip", "ZIP Archive", "application/zip", FileCategory.ARCHIVE)
    )

    fun getAvailableOutputs(inputCategory: FileCategory, inputExt: String): List<FileFormat> {
        val lowerExt = inputExt.lowercase().trimStart('.')
        return when (inputCategory) {
            FileCategory.IMAGE -> IMAGE_FORMATS.filter { it.extension != lowerExt }
            FileCategory.DOCUMENT -> {
                when (lowerExt) {
                    "pdf" -> listOf(
                        FileFormat("jpg", "Render Pages to JPG", "image/jpeg", FileCategory.IMAGE),
                        FileFormat("png", "Render Pages to PNG", "image/png", FileCategory.IMAGE),
                        FileFormat("webp", "Render Pages to WebP", "image/webp", FileCategory.IMAGE),
                        FileFormat("zip", "ZIP Archive", "application/zip", FileCategory.ARCHIVE)
                    )
                    "html", "htm" -> listOf(
                        FileFormat("pdf", "PDF Document", "application/pdf", FileCategory.DOCUMENT),
                        FileFormat("txt", "Plain Text", "text/plain", FileCategory.DOCUMENT),
                        FileFormat("zip", "ZIP Archive", "application/zip", FileCategory.ARCHIVE)
                    )
                    else -> listOf(
                        FileFormat("pdf", "PDF Document", "application/pdf", FileCategory.DOCUMENT),
                        FileFormat("html", "HTML Webpage", "text/html", FileCategory.DOCUMENT),
                        FileFormat("zip", "ZIP Archive", "application/zip", FileCategory.ARCHIVE)
                    )
                }
            }
            FileCategory.AUDIO -> AUDIO_FORMATS.filter { it.extension != lowerExt }
            FileCategory.VIDEO -> VIDEO_FORMATS
            FileCategory.ARCHIVE -> listOf(
                FileFormat("zip", "Re-compress ZIP", "application/zip", FileCategory.ARCHIVE)
            )
            FileCategory.OTHER -> listOf(
                FileFormat("zip", "Compress to ZIP", "application/zip", FileCategory.ARCHIVE)
            )
        }
    }
}
