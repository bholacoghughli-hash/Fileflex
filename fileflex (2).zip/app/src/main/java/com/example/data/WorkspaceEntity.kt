package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "workspace_files")
data class WorkspaceEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val fileName: String,
    val filePath: String,
    val fileExtension: String,
    val category: String,
    val sizeBytes: Long,
    val isFavorite: Boolean = false,
    val tag: String = "CONVERTED", // CONVERTED, EDITED, IMPORTED
    val lastModified: Long = System.currentTimeMillis()
) {
    val formattedSize: String
        get() = when {
            sizeBytes >= 1024 * 1024 -> String.format("%.2f MB", sizeBytes / (1024.0 * 1024.0))
            sizeBytes >= 1024 -> String.format("%.1f KB", sizeBytes / 1024.0)
            else -> "$sizeBytes B"
        }
}
