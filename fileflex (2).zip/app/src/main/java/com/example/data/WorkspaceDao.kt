package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface WorkspaceDao {

    @Query("SELECT * FROM workspace_files ORDER BY lastModified DESC")
    fun getAllFiles(): Flow<List<WorkspaceEntity>>

    @Query("SELECT * FROM workspace_files WHERE isFavorite = 1 ORDER BY lastModified DESC")
    fun getFavoriteFiles(): Flow<List<WorkspaceEntity>>

    @Query("SELECT * FROM workspace_files WHERE tag = :tag ORDER BY lastModified DESC")
    fun getFilesByTag(tag: String): Flow<List<WorkspaceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(file: WorkspaceEntity): Long

    @Update
    suspend fun update(file: WorkspaceEntity)

    @Delete
    suspend fun delete(file: WorkspaceEntity)

    @Query("DELETE FROM workspace_files WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("UPDATE workspace_files SET isFavorite = :isFavorite WHERE id = :id")
    suspend fun updateFavorite(id: Long, isFavorite: Boolean)

    @Query("UPDATE workspace_files SET fileName = :newName WHERE id = :id")
    suspend fun renameFile(id: Long, newName: String)

    @Query("SELECT * FROM workspace_files WHERE filePath = :path LIMIT 1")
    suspend fun findByPath(path: String): WorkspaceEntity?
}
