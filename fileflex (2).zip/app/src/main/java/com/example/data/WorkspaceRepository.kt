package com.example.data

import kotlinx.coroutines.flow.Flow
import java.io.File

class WorkspaceRepository(private val workspaceDao: WorkspaceDao) {

    val allFiles: Flow<List<WorkspaceEntity>> = workspaceDao.getAllFiles()
    val favoriteFiles: Flow<List<WorkspaceEntity>> = workspaceDao.getFavoriteFiles()

    suspend fun addFile(
        file: File,
        tag: String = "EDITED",
        category: String = "DOCUMENT"
    ): Long {
        val entity = WorkspaceEntity(
            fileName = file.name,
            filePath = file.absolutePath,
            fileExtension = file.extension.lowercase(),
            category = category,
            sizeBytes = file.length(),
            isFavorite = false,
            tag = tag,
            lastModified = System.currentTimeMillis()
        )
        return workspaceDao.insert(entity)
    }

    suspend fun toggleFavorite(id: Long, currentFavorite: Boolean) {
        workspaceDao.updateFavorite(id, !currentFavorite)
    }

    suspend fun rename(id: Long, newName: String) {
        workspaceDao.renameFile(id, newName)
    }

    suspend fun remove(entity: WorkspaceEntity, deletePhysicalFile: Boolean = false) {
        workspaceDao.delete(entity)
        if (deletePhysicalFile) {
            val file = File(entity.filePath)
            if (file.exists()) file.delete()
        }
    }
}
