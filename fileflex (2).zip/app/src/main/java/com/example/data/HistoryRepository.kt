package com.example.data

import kotlinx.coroutines.flow.Flow

class HistoryRepository(private val historyDao: HistoryDao) {
    val allHistory: Flow<List<ConversionHistoryEntity>> = historyDao.getAllHistory()
    val historyCount: Flow<Int> = historyDao.getHistoryCount()

    fun getHistoryByCategory(category: String): Flow<List<ConversionHistoryEntity>> {
        return historyDao.getHistoryByCategory(category)
    }

    suspend fun insert(item: ConversionHistoryEntity): Long {
        return historyDao.insertHistory(item)
    }

    suspend fun deleteById(id: Long) {
        historyDao.deleteById(id)
    }

    suspend fun clearAll() {
        historyDao.clearAll()
    }
}
