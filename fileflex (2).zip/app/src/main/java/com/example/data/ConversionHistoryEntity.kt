package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "conversion_history")
data class ConversionHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val fileName: String,
    val outputFileName: String,
    val originalFormat: String,
    val targetFormat: String,
    val category: String,
    val originalSizeBytes: Long,
    val convertedSizeBytes: Long,
    val durationMs: Long,
    val status: String,
    val timestamp: Long = System.currentTimeMillis(),
    val outputFilePath: String? = null,
    val errorMessage: String? = null
) {
    val formattedOriginalSize: String
        get() = when {
            originalSizeBytes >= 1024 * 1024 -> String.format("%.2f MB", originalSizeBytes / (1024.0 * 1024.0))
            originalSizeBytes >= 1024 -> String.format("%.1f KB", originalSizeBytes / 1024.0)
            else -> "$originalSizeBytes B"
        }

    val formattedConvertedSize: String
        get() = when {
            convertedSizeBytes >= 1024 * 1024 -> String.format("%.2f MB", convertedSizeBytes / (1024.0 * 1024.0))
            convertedSizeBytes >= 1024 -> String.format("%.1f KB", convertedSizeBytes / 1024.0)
            else -> "$convertedSizeBytes B"
        }
}
